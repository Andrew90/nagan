#include <gsl/gsl_errno.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_fft_real.h>
#include <gsl/gsl_fft_halfcomplex.h>

// #define __DEBUG__

#include "test.h"

void diff( 	const int32_t * const data,
			const int32_t Ndata,  
			int32_t *diffs, 
			const int32_t Ndiffs  )
{
	int32_t i;
	
	//! @todo добавить проверку входных данных
	
	for( i = 0; i < Ndata - 1; i++ )
	{
        diffs[i] = data[i+1] - data[i];
	}	
}

EXPORT int xcorr( const int8_t data[], int32_t acf[], int32_t N )
{
	int i;
	int retval = 0;
	
	const int Nfft = 1 << ( (int) ceil( log( 2 * N - 1 ) / log( 2 ) ));
	
	double *fft_conv = (double *) malloc( Nfft * sizeof(double) );
	
	if( fft_conv == NULL )
	{
		return -1;
	}
	
	for( i = 0; i < N; i++ )
		fft_conv[i] = (double) data[i];
	for( i = N; i < Nfft; i++ )
		fft_conv[i] = 0.0;

	if( gsl_fft_real_radix2_transform( fft_conv, 1, Nfft ) != 0 )
	{
		retval = -1;
		goto end;
	}
	else
	{
		for( i = 0; i < Nfft / 2; i++ )
		{
				if( (i == 0) || ( i == (Nfft/2-1) ) )
						fft_conv[i] *= fft_conv[i];
				else
				{
					int ni = Nfft - i;
					fft_conv[i]  = fft_conv[i] * fft_conv[i]  + fft_conv[ni] * fft_conv[ni];
					fft_conv[ni] = 0.0;
				}
		}
		
		gsl_fft_halfcomplex_radix2_inverse( fft_conv, 1, Nfft );
		
		for( i = 0; i < N; i++ )
			acf[i] = lround ( fft_conv[i] );
	}
end:	
	free( fft_conv );
	return retval;
}

EXPORT void envelope ( int32_t * y, 
					   int32_t Ny,
					   double  * curve  )
{
	double *maxs, *indexes;
	int32_t *diffs;
	int32_t i;
	int32_t Npts = 0;

#if defined __DEBUG__	
	FILE* f = fopen("log.txt","w");
#endif
	
	diffs   = (int32_t *) malloc( (Ny-1) * sizeof(int32_t) );
	maxs    = (double  *) malloc( (Ny-1) * sizeof(double) );
	indexes = (double  *) malloc( (Ny-1) * sizeof(double) );
	
	indexes[ Npts ] = 0.0; maxs[ Npts ] = y[ Npts ];
#if defined __DEBUG__
	fprintf( f, "	indexes[ %d ] = %g; maxs[ %d ] = %g\n", Npts, indexes[ Npts], Npts, maxs[ Npts ] );
#endif
	++Npts;

#if defined __DEBUG__
	fprintf( f, "Before diff\n" );
#endif
	diff( y, Ny, diffs, Ny - 1 );
#if defined __DEBUG__
	fprintf( f, "After diff\n" );
#endif
	
	for( i = 0; i < Ny - 1; i++ )
	{
		if( diffs[i] > 0 )
		{
			if( diffs[i+1] < 0 )
			{
				indexes[ Npts ] = (double)(i + 1);
				maxs[ Npts ]    = (double)y[i+1];
#if defined __DEBUG__				
				fprintf( f, "	indexes[ %d ] = %g; maxs[ %d ] = %g\n", Npts, indexes[ Npts], Npts, maxs[ Npts ] );
#endif
				++Npts;
			}
		}
	}
	
	if( indexes[ Npts - 1] != Ny - 1 )
	{
		indexes[ Npts ] = Ny - 1; maxs[ Npts ] = y[ Ny - 1];
#if defined __DEBUG__
		fprintf( f, "	indexes[ %d ] = %g; maxs[ %d ] = %g\n", Npts, indexes[ Npts], Npts, maxs[ Npts ] );
#endif
		++Npts;
	}

#if defined __DEBUG__	
	fprintf( f, "	Npts = %d\n", Npts );
#endif	
	const gsl_interp_type *t = gsl_interp_cspline; 
	gsl_interp_accel *accel_ptr  = gsl_interp_accel_alloc();
	gsl_spline 		 *spline_ptr = gsl_spline_alloc( t, Npts );

#if defined __DEBUG__
	fprintf( f, "After alloc\n" );
#endif	
	gsl_spline_init( spline_ptr, indexes, maxs, Npts );

#if defined __DEBUG__
	fprintf( f, "After init\n" );
#endif
	double max_value = 1.0e-3;
	for( i = 1; i < Ny; i++ )
	{
		curve[i] = gsl_spline_eval( spline_ptr, (double)i, accel_ptr );
		
		// попутно ищем максимальное значение 
		if( curve[i] > max_value )
			max_value = curve[i];
		
#if defined __DEBUG__
		fprintf( f, "    i = %d, eval = %g\n", i, curve[i] );
#endif
	}

#if defined __DEBUG__
	fprintf( f, "After eval\n" );
#endif
	
	// выполняем нормирование функции
	for( i = 0; i < Ny; i++ )
		curve[i] = curve[i] / max_value;
		
#if defined __DEBUG__	
	fprintf( f, "After normalization: max_value = %g\n", max_value );
	fclose( f );
#endif



	gsl_spline_free( spline_ptr );
	gsl_interp_accel_free( accel_ptr );
	
	free( diffs );
	free( maxs );
	free( indexes );
}
