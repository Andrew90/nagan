 #include <stdlib.h>
 #include <stdio.h>
 #include <math.h>
 #include <time.h>
 
#include <gsl/gsl_errno.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_fft_real.h>
#include <gsl/gsl_fft_halfcomplex.h>

 
  int main (void)
 {

	
	int i;
	int N = 8;
	int *data;
	double *fft_conv;

	int Nfft = 1 << ( (int) ceil( log( 2 * N - 1 ) / log( 2 ) ));
	//int Nfft = 1 << ( (int) ceil( log( 2 * N ) / log( 2 ) ));
	
	//N = Nfft;
	
	printf( "Nfft = %d\n", Nfft );
	
	data = (int *) malloc( N * sizeof( int ) );
	
	/* initialize random seed: */
	srand ( time(NULL) );
	
	for( i = 0; i < N; i++ ) 
		data[i] = 1;


	fft_conv = (double *) malloc( Nfft * sizeof(double) );
	
	if( fft_conv == NULL )
	{
		return -1;
	}
	
	for( i = 0; i < N; i++ )
	{
		fft_conv[i] = (double) data[i];
	}
	for( i = N; i < Nfft; i++ )
		fft_conv[i] = 0.0;
	
	if( gsl_fft_real_radix2_transform( fft_conv, 1, Nfft ) != 0 )
	{
		printf( "Error during gsl_fft_real_radix2_transform" );
	}
	else
	{
		for( i = 0; i < Nfft / 2; i++ )
		{
				if( (i == 0) || ( i == (Nfft/2-1) ) )
						fft_conv[i] *= fft_conv[i];
				else
				{
					int ni = Nfft - i;
					//double dReal = fft_conv[i] * fft_conv[i]  + fft_conv[ni] * fft_conv[ni];
					//double dImag = fft_conv[i] * fft_conv[ni] - fft_conv[ni] * fft_conv[i];
					fft_conv[i]  = fft_conv[i] * fft_conv[i]  + fft_conv[ni] * fft_conv[ni];
					fft_conv[ni] = 0.0;
				}
		}
		
		gsl_fft_halfcomplex_radix2_inverse( fft_conv, 1, Nfft );
		
		for( i = 0; i < Nfft; i++ )
		{
			int tmp = lround( fft_conv[i] );
			printf( "i = %d  ACF = %d\n", i, tmp );
		}
	}
	
	free( data );
	free( fft_conv );
 }
 
 /*
 int main (void)
 {
   int N = 4;
   double x[4] = {0.00, 0.10,  0.27,  0.30};
   double y[4] = {0.15, 0.70, -0.10,  0.15}; 
			  // Note: y[0] == y[3] for periodic data 
 
   gsl_interp_accel *acc = gsl_interp_accel_alloc ();
   const gsl_interp_type *t = gsl_interp_cspline_periodic; 
   gsl_spline *spline = gsl_spline_alloc (t, N);
 
   int i; double xi, yi;
 
   printf ("#m=0,S=5\n");
   for (i = 0; i < N; i++)
	 {
	   printf ("%g %g\n", x[i], y[i]);
	 }
 
   printf ("#m=1,S=0\n");
   gsl_spline_init (spline, x, y, N);
 
   for (i = 0; i <= 100; i++)
	 {
	   xi = (1 - i / 100.0) * x[0] + (i / 100.0) * x[N-1];
	   yi = gsl_spline_eval (spline, xi, acc);
	   printf ("%g %g\n", xi, yi);
	 }
   
   gsl_spline_free (spline);
   gsl_interp_accel_free (acc);
   return 0;
 } */