#ifndef TEST_H
#define TEST_H

#include <stdint.h>

#define BUILD_DLL

#ifdef BUILD_DLL
   // the dll exports
   #define EXPORT __declspec(dllexport)
#else
   // the exe imports
   #define EXPORT __declspec(dllimport)
#endif

void diff( 	const int32_t * const data,
			const int32_t Ndata,  
			int32_t *diffs, 
			const int32_t Ndiffs  );

EXPORT void envelope( int32_t * y, int32_t Ny, double*  curve  );

EXPORT int 	xcorr	( const int8_t data[], int32_t acf[], int32_t N );					   

#endif